---
layout: page
title: "关于：About"
---
Welcome to visit my blog!

#### 1.Personal Info
Name: nongbin  
Gender: Male  
City: nanning, China  
Career: Software developer(Android&Linux&Web)  

#### 2.My Links
Blog: <http://blog.nongbin.online>  
GitHub: <https://github.com/nongbin>  
LinkedIn: <http://www.linkedin.com/in/%E6%96%8C-%E5%86%9C-844523a2/>  


#### 3.Contract
Email: 1784855023@qq.com 
QQ: 1784855023

### 4.Domain For Sale
danbaili.com  
fangxinyu.com  
maicaiwa.com  
babytoycar.com  
youth168.com  
