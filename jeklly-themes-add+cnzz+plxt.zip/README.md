Jekyll博客模板
================

#### 1.浏览
http://blog.nongbin.online, 支持PC与智能机访问。  

#### 2.模板使用
修改_config.yml与_includes目录下相关文件进行配置。  
模板可任意使用，但请保留本站**友情链接**。  

#### 3.本人联系方式（非作者）
Email:1784855023@qq.com
 
 
转载于：		
					潘学文博客 https://www.panxw.com
(作者博客)
